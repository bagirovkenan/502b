
// // $(document).ready(function(){
//     $(".btn1").click(function(){
//         $("p").hide();
//     });
//     $(".btn2").click(function(){
//         $("p").show();
//     });
// });

// $(document).ready(function(){
//     $("#bir").click(function(){
//         $("#div1").show()
//     })
// })