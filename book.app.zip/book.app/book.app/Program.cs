﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BooksWork
{
    class Book
    {
        public string basliq;
        public string yazici;
        public int sehife;
    }

    class Program
    {
        static int a = 0;
        static Book[] kitabliq = new Book[100];

        public static void kitabartir()
        {
            Console.Write("kitabin basligini yazin:");
            var title = Console.ReadLine();
            Console.Write("muellifi yazin:");
            var author = Console.ReadLine();
            Console.Write("sehifeni yazin:");
            var pages = 0;
            try
            {
                pages = int.Parse(Console.ReadLine());
            }

            catch
            {
                pages = 0;
            }
            Book yeniKitab = new Book() { basliq = title, sehife = pages, yazici = author };
            kitabliq[a] = yeniKitab;
            a++;
        }
        public static void kitabaxtar()
        {
            Console.Write("Istediyiniz kitabi tapmaq ucun basligi yazin: ");
            var name = Console.ReadLine();

            for (var m = 0; m < a; m++)
            {
                string search = (kitabliq[m].basliq.ToUpper().Trim());

                if (search == name.ToUpper().Trim())
                {

                    Console.WriteLine("Istediyiniz kitab tapildi");
                    Console.WriteLine("ve nomresi " + m);


                }



            }
        }


        private static void kitabsil()
        {
            Console.Write("Silmek istediyiniz kitab ucun kodunu yazin: ");
            var delet = Console.ReadLine();

            for (var j = 0; j < a; j++)
            {
                string delete = (kitabliq[j].basliq.ToUpper().Trim());

                if (delete == delet.ToUpper().Trim())
                {

                    Console.WriteLine("kitab silindi");



                }



            }
        }


      


        static void Main(string[] args)
        {


            while (true)
            {
                Console.WriteLine("1 - Kitab artir");
                Console.WriteLine("2 - Kitabi axtar");
                Console.WriteLine("3 - Kitabi sil");
                var result = Console.ReadLine();
                switch (result)
                {
                    case "1": kitabartir(); break;
                    case "2": kitabaxtar(); break;
                    case "3": kitabsil(); break;
                    default: Console.WriteLine("Duz secim edin"); break;
                }
            }

            var answer = "he";
            while (answer.ToUpper() == "HE")
            {
                Console.WriteLine("kitabin basligini yazin");
                kitabliq[a].basliq = Console.ReadLine();
                Console.WriteLine("muellifi yazin");
                kitabliq[a].yazici = Console.ReadLine();
                Console.WriteLine("sehifeni yazin:");
                try
                {
                    kitabliq[a].sehife = int.Parse(Console.ReadLine());
                }

                catch
                {
                    kitabliq[a].sehife = 0;
                }
                if (answer == "yox")
                {
                    Console.WriteLine("cixmaq ucun her hansi bir duymeye basin");
                    break;
                }

                Console.WriteLine("Davam etmek isteyirsiz?");

                answer = Console.ReadLine();
                a++;

            }





        }


    }

   
}