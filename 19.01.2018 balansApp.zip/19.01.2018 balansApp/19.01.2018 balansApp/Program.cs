﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19._01._2018_balansApp
{
    class Program
    {
        static void Main(string[] args)


        {

           

            phone telefon = new phone (100);
            while (telefon.getBalance() > 0)
            {
                //Console.Write("saniye daxil edin:");
                double saniye = double.Parse(Console.ReadLine());
                telefon.makeCall(saniye);
                if(((saniye * 7) / 60) > telefon.getBalance())
                {
                     Console.WriteLine("balance bitmisdir"); 
                }
               else
                {
                    Console.WriteLine(telefon.getBalance());
                }

               
            }
          //  Console.WriteLine(telefon.makeCall());

        }


        class phone
        {
            public string make;
            public string model;
            public int    memeory;
            public int    cpu;
            public double display;
            public double balance;

            public phone(double Balans)
            {
                balance = Balans;
            }

            public double getBalance()

            {
                return balance;
            }

            public void makeCall(double san)
            {
                

                   balance -= (san * 7) / 60;

            }

            //class ekran
            //{
            //    public double diagonal;
            //    public int tyep;


            } //}
        }
}
